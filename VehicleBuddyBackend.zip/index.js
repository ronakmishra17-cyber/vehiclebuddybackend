const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 5000;

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log("MongoDB connection error:", err));

// Vehicle schema
const vehicleSchema = new mongoose.Schema({
  vehicleNumber: { type: String, required: true, unique: true },
  vehicleName: { type: String, required: true },
  kmData: [{ km: Number, date: { type: Date, default: Date.now } }],
  fuelData: [{ cost: Number, litres: Number, date: { type: Date, default: Date.now } }]
});

const Vehicle = mongoose.model("Vehicle", vehicleSchema);

// Routes

// Register
app.post("/api/register", async (req, res) => {
  const { vehicleNumber, vehicleName } = req.body;
  try {
    const exists = await Vehicle.findOne({ vehicleNumber });
    if (exists) return res.status(400).json({ message: "Vehicle already exists" });
    const newVehicle = new Vehicle({ vehicleNumber, vehicleName });
    await newVehicle.save();
    res.json({ message: "Registered successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  const { vehicleNumber } = req.body;
  try {
    const vehicle = await Vehicle.findOne({ vehicleNumber });
    if (!vehicle) return res.status(400).json({ message: "Vehicle not found" });
    res.json({ vehicle });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add KM
app.post("/api/km", async (req, res) => {
  const { vehicleNumber, km } = req.body;
  try {
    const vehicle = await Vehicle.findOne({ vehicleNumber });
    if (!vehicle) return res.status(400).json({ message: "Vehicle not found" });
    vehicle.kmData.push({ km });
    await vehicle.save();
    res.json({ message: "KM added successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add Fuel
app.post("/api/fuel", async (req, res) => {
  const { vehicleNumber, cost, litres } = req.body;
  try {
    const vehicle = await Vehicle.findOne({ vehicleNumber });
    if (!vehicle) return res.status(400).json({ message: "Vehicle not found" });
    vehicle.fuelData.push({ cost, litres });
    await vehicle.save();
    res.json({ message: "Fuel added successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
